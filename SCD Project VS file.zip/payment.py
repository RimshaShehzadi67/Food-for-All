import tkinter as tk
from PIL import Image, ImageTk
import sqlite3
import os
import sys

img_path = sys.argv[1] if len(sys.argv) > 1 else "assets/98.png"
title = sys.argv[2] if len(sys.argv) > 2 else "Product Name"
price = sys.argv[3] if len(sys.argv) > 3 else "$0.00"

LOGO_PATH = "assets/foodforall.jpg"
DB_PATH = "users.db"

root = tk.Tk()
root.title("Payment Page")
root.geometry("1100x700")
root.configure(bg="white")

# Navbar
navbar = tk.Frame(root, bg="#29a3ef", height=70)
navbar.pack(fill="x")

if os.path.exists(LOGO_PATH):
    logo_img = Image.open(LOGO_PATH).resize((50, 50))
    logo_photo = ImageTk.PhotoImage(logo_img)
    tk.Label(navbar, image=logo_photo, bg="#29a3ef").place(x=10, y=10)

tk.Label(navbar, text="FOOD FOR ALL", font=("Arial", 18, "bold"), bg="#29a3ef", fg="white").pack(pady=(8, 0))
tk.Label(navbar, text="Feed All, Treat Well, Donate!", font=("Arial", 9), bg="#29a3ef", fg="white").pack()

# Main Frame
main_frame = tk.Frame(root, bg="white")
main_frame.pack(pady=10)

# Left card
left_card = tk.Frame(main_frame, width=450, height=370, bg="white", highlightbackground="gray", highlightthickness=1)
left_card.pack(side="left", padx=10)
left_card.pack_propagate(False)

if os.path.exists(img_path):
    food_img = Image.open(img_path).resize((400, 220))
    food_photo = ImageTk.PhotoImage(food_img)
    tk.Label(left_card, image=food_photo, bg="white").pack(pady=5)
else:
    tk.Label(left_card, text="[Image not found]", bg="white", fg="red").pack()

tk.Label(left_card, text=title, font=("Arial", 14, "bold"), bg="white").pack()
tk.Label(left_card, text=price, font=("Arial", 12), fg="red", bg="white").pack()
tk.Label(left_card, text="XXXX-XXXX-XXXX-1234", bg="#f5f5f5", font=("Arial", 10), width=30).pack(pady=5)

# Right card
right_card = tk.Frame(main_frame, width=450, height=370, bg="white", highlightbackground="gray", highlightthickness=1)
right_card.pack(side="right", padx=10)
right_card.pack_propagate(False)

tk.Label(right_card, text="Payment Page", font=("Arial", 16, "bold"), bg="white").pack(pady=10)

def add_entry(label_text, default_text):
    tk.Label(right_card, text=label_text, font=("Arial", 10), bg="white").pack(anchor="w", padx=20)
    entry = tk.Entry(right_card, font=("Arial", 10), width=35)
    entry.insert(0, default_text)
    entry.pack(padx=20, pady=3)

add_entry("Cardholder Name", "John Doe")
add_entry("Card Number", "1234 5678 9012 3456")
add_entry("Expiry Date", "MM/YY")
add_entry("CVV", "123")

card_type = tk.StringVar(value="Credit")
card_frame = tk.Frame(right_card, bg="white")
card_frame.pack(pady=5)
tk.Radiobutton(card_frame, text="Credit Card", variable=card_type, value="Credit", bg="white", font=("Arial", 9)).pack(side="left", padx=10)
tk.Radiobutton(card_frame, text="Debit Card", variable=card_type, value="Debit", bg="white", font=("Arial", 9)).pack(side="left", padx=10)

tk.Button(right_card, text="PAY NOW", bg="#ff3b1f", fg="white", font=("Arial", 11, "bold"),
          width=30, height=1, bd=0).pack(pady=8)

# Order history
history_frame = tk.Frame(root, bg="white")
history_frame.pack(fill="both", expand=False, padx=30, pady=(10, 10))

tk.Label(history_frame, text="Welcome!", font=("Arial", 13, "bold"), bg="white").pack(anchor="w")
tk.Label(history_frame, text="Order History", font=("Arial", 11, "bold"), bg="white").pack(anchor="w", pady=(5, 3))

order_container = tk.Frame(history_frame, bg="white")
order_container.pack()

def load_order_history():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS orders (username TEXT, item TEXT, date TEXT)''')
    conn.commit()

    c.execute("SELECT COUNT(*) FROM orders")
    if c.fetchone()[0] == 0:
        c.executemany("INSERT INTO orders (username, item, date) VALUES (?, ?, ?)", [
            ("Ali", "Ali Farms", "01-12-2024"),
            ("Ali", "PC Hotel", "23-02-2024"),
            ("Ali", "Food For All Warehouse", "23-02-2024"),
        ])
        conn.commit()

    c.execute("SELECT item, date FROM orders")
    rows = c.fetchall()
    conn.close()

    for item, date in rows:
        item_frame = tk.Frame(order_container, bg="#f2f2f2", width=140, height=60, padx=5, pady=5, bd=1, relief="solid")
        item_frame.pack(side="left", padx=10)
        item_frame.pack_propagate(False)

        tk.Label(item_frame, text=item, font=("Arial", 9, "bold"), bg="#f2f2f2").pack(anchor="center")
        tk.Label(item_frame, text=date, font=("Arial", 8), bg="#f2f2f2").pack(anchor="center")

load_order_history()

root.mainloop()
