import unittest
import os
from PIL import Image

class TestFoodForAllApp(unittest.TestCase):

    def test_home_page_loads(self):
        """Ensure home page script exists and can be imported."""
        try:
            import home
            self.assertTrue(hasattr(home, 'home_page'))
        except ImportError:
            self.fail("Home page script or function not found")

    def test_edible_page_function_exists(self):
        """Check edible page function."""
        try:
            import csr
            self.assertTrue(hasattr(csr, 'edible_page'))
        except ImportError:
            self.fail("CSR (edible) page not found or import failed")

    def test_waste_page_function_exists(self):
        """Check waste page function."""
        try:
            import waste
            self.assertTrue(hasattr(waste, 'waste_page'))
        except ImportError:
            self.fail("Waste page not found or import failed")

    def test_images_exist_in_assets(self):
        """Verify all required image files exist in assets/"""
        image_files = [
            "assets/1.jpg", "assets/9.png", "assets/6.png", "assets/5.png",
            "assets/98.png", "assets/9.jpg", "assets/96.png", "assets/foodforall.jpg"
        ]
        for img in image_files:
            with self.subTest(img=img):
                self.assertTrue(os.path.exists(img), f"{img} is missing")

    def test_image_opening(self):
        """Ensure images can be opened by PIL."""
        try:
            img = Image.open("assets/1.jpg")
            img.verify()  # Will raise an exception if image is broken
        except Exception as e:
            self.fail(f"Failed to open/verify image: {e}")

    def test_navigation_scripts_exist(self):
        """Check that nav target scripts exist."""
        files = ["home.py", "csr.py", "waste.py", "about.py", "who_we_are.py", "login.py"]
        for f in files:
            with self.subTest(script=f):
                self.assertTrue(os.path.exists(f), f"{f} script missing")

    def test_location_script_exists(self):
        """Ensure location script exists."""
        self.assertTrue(os.path.exists("location.py"), "location.py not found")

    def test_payment_script_exists(self):
        """Ensure payment script exists."""
        self.assertTrue(os.path.exists("payment.py"), "payment.py not found")

    def test_edible_food_items_count(self):
        """CSR page should define 3 food items."""
        foods = [
            {"name": "BIRYANI", "image": "assets/98.png", "rating": 4},
            {"name": "SAMOSA", "image": "assets/9.jpg", "rating": 3},
            {"name": "VEGETABLE RICE", "image": "assets/96.png", "rating": 5},
        ]
        self.assertEqual(len(foods), 3, "CSR must contain 3 food cards")

    def test_waste_products_count(self):
        """Waste page should define 3 products."""
        products = [
            {"image": "assets/9.png", "title": "Ali Farms", "price": "$50.00"},
            {"image": "assets/6.png", "title": "PC Hotel", "price": "$20.00"},
            {"image": "assets/5.png", "title": "Food For All", "price": "$30.00"},
        ]
        self.assertEqual(len(products), 3, "Waste must contain 3 product cards")


if __name__ == "__main__":
    unittest.main()
