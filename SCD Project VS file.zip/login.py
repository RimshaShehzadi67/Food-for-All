import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk
from admin import admin_page  # ✅ Admin GUI
from rider import launch_dashboard  # ✅ Rider Dashboard GUI

import sqlite3
import os

# ------------------ DATABASE ------------------ #
conn = sqlite3.connect('users.db')
cursor = conn.cursor()
cursor.execute('''CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY,
                    fullname TEXT NOT NULL,
                    email TEXT NOT NULL UNIQUE,
                    password TEXT NOT NULL
                )''')
conn.commit()

# ------------------ CONSTANTS ------------------ #
ADMIN_EMAIL = "admin@foodforall.com"
ADMIN_PASSWORD = "admin123"
BACKGROUND_IMAGE = "assets/1.jpg"

# ------------------ UI HELPERS ------------------ #
def center_window(win, width=600, height=500):
    screen_width = win.winfo_screenwidth()
    screen_height = win.winfo_screenheight()
    x = (screen_width // 2) - (width // 2)
    y = (screen_height // 2) - (height // 2)
    win.geometry(f'{width}x{height}+{x}+{y}')

def set_background(window, canvas):
    bg_image = Image.open(BACKGROUND_IMAGE)
    bg_image = bg_image.resize((600, 500))
    bg = ImageTk.PhotoImage(bg_image)
    canvas.bg_img = bg
    canvas.create_image(0, 0, anchor=tk.NW, image=bg)

# ------------------ REGISTER ------------------ #
def register_page():
    register_win = tk.Tk()
    register_win.title("Register")
    center_window(register_win)

    canvas = tk.Canvas(register_win, width=600, height=500)
    canvas.pack(fill="both", expand=True)
    set_background(register_win, canvas)

    frame = tk.Frame(register_win, bg='white', padx=30, pady=30)
    frame.place(relx=0.5, rely=0.5, anchor='center')

    tk.Label(frame, text="Create an Account", font=("Arial", 16, "bold"), bg='white').grid(row=0, column=0, columnspan=2, pady=10)

    fullname = tk.Entry(frame, width=40)
    fullname.insert(0, "Full Name")
    fullname.grid(row=1, column=0, columnspan=2, pady=5)

    email = tk.Entry(frame, width=40)
    email.insert(0, "Email")
    email.grid(row=2, column=0, columnspan=2, pady=5)

    password = tk.Entry(frame, width=40, show='*')
    password.insert(0, "Password")
    password.grid(row=3, column=0, columnspan=2, pady=5)

    confirm = tk.Entry(frame, width=40, show='*')
    confirm.insert(0, "Confirm Password")
    confirm.grid(row=4, column=0, columnspan=2, pady=5)

    def register():
        if not fullname.get() or not email.get() or not password.get():
            messagebox.showwarning("Error", "All fields are required")
            return
        if password.get() != confirm.get():
            messagebox.showwarning("Error", "Passwords do not match")
            return
        try:
            cursor.execute("INSERT INTO users (fullname, email, password) VALUES (?, ?, ?)",
                           (fullname.get(), email.get(), password.get()))
            conn.commit()
            messagebox.showinfo("Success", "Registered successfully!")
            register_win.destroy()
            login_window()
        except sqlite3.IntegrityError:
            messagebox.showerror("Error", "Email already registered")

    tk.Button(frame, text="Register", bg="red", fg="white", command=register, width=30).grid(row=5, column=0, columnspan=2, pady=10)
    tk.Button(frame, text="Already have an account? Login", command=lambda: [register_win.destroy(), login_window()],
              bg="white", fg="blue", relief="flat").grid(row=6, column=0, columnspan=2, pady=5)

    register_win.mainloop()

# ------------------ LOGIN ------------------ #
def login_window():
    login_win = tk.Tk()
    login_win.title("Login")
    center_window(login_win)

    canvas = tk.Canvas(login_win, width=600, height=500)
    canvas.pack(fill="both", expand=True)
    set_background(login_win, canvas)

    frame = tk.Frame(login_win, bg='white', padx=30, pady=30)
    frame.place(relx=0.5, rely=0.5, anchor='center')

    tk.Label(frame, text="Login", font=("Arial", 16, "bold"), bg='white').grid(row=0, column=0, columnspan=2, pady=10)

    username = tk.Entry(frame, width=40)
    username.insert(0, "Email")
    username.grid(row=1, column=0, columnspan=2, pady=5)

    password = tk.Entry(frame, width=40, show='*')
    password.insert(0, "Password")
    password.grid(row=2, column=0, columnspan=2, pady=5)

    def login_as(role):
        email = username.get()
        pwd = password.get()
        if email == ADMIN_EMAIL and pwd == ADMIN_PASSWORD:
            login_win.destroy()
            admin_page()
        else:
            cursor.execute("SELECT * FROM users WHERE email=? AND password=?", (email, pwd))
            user = cursor.fetchone()
            if user:
                login_win.destroy()
                rider_page(user[1])  # ✅ pass fullname
            else:
                messagebox.showerror("Login Failed", "Invalid credentials")

    tk.Button(frame, text="Login as Admin", bg="red", fg="white", width=30, command=lambda: login_as('admin')).grid(row=3, column=0, columnspan=2, pady=5)
    tk.Button(frame, text="Login as Rider", bg="red", fg="white", width=30, command=lambda: login_as('rider')).grid(row=4, column=0, columnspan=2, pady=5)

    tk.Button(frame, text="Forgot Password?", bg="white", fg="red", relief="flat").grid(row=5, column=0, columnspan=2)
    tk.Button(frame, text="Don't have an account? Sign up", command=lambda: [login_win.destroy(), register_page()],
              bg="white", fg="blue", relief="flat").grid(row=6, column=0, columnspan=2, pady=5)

    login_win.mainloop()

# ------------------ REAL RIDER PAGE ------------------ #
def rider_page(name):
    launch_dashboard(name)

# ------------------ START APP (FOR STANDALONE TESTING ONLY) ------------------ #
# if __name__ == "__main__":
#     if not os.path.exists(BACKGROUND_IMAGE):
#         print(f"Background image '{BACKGROUND_IMAGE}' not found! Please add it to the directory.")
#     else:
#         register_page()
