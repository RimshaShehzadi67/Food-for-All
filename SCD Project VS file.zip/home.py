import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk
import login, csr, waste, about, who_we_are

def home_page():
    root = tk.Tk()
    root.title("Food For All")
    root.geometry("900x600")
    root.resizable(False, False)

    # Optional: Maximize window
    #root.state('zoomed')

    # Background image
    bg_image = Image.open("assets/1.jpg").resize((900, 600))
    bg_photo = ImageTk.PhotoImage(bg_image)

    canvas = tk.Canvas(root, width=900, height=600)
    canvas.pack(fill="both", expand=True)
    canvas.create_image(0, 0, image=bg_photo, anchor="nw")
    canvas.bg_photo = bg_photo  # prevent garbage collection

    # Header section
    canvas.create_rectangle(0, 0, 900, 80, fill="#00BFFF", outline="")

    # Logo
    try:
        logo_img = Image.open("assets/foodforall.jpg").resize((60, 60), Image.LANCZOS)
        logo_photo = ImageTk.PhotoImage(logo_img)
        canvas.create_image(20, 10, anchor="nw", image=logo_photo)
        canvas.logo_photo = logo_photo
    except Exception as e:
        print("Logo loading error:", e)

    # Title and slogan
    canvas.create_text(100, 25, text="FOOD FOR ALL", fill="white", font=("Arial", 24, "bold"), anchor="nw")
    canvas.create_text(100, 55, text="Feed All, Treat Well, Donate!", fill="white", font=("Arial", 14), anchor="nw")

    # Navigation bar background
    nav_bar = tk.Frame(root, bg="#009CA6")
    nav_bar.place(x=0, y=80, width=900, height=40)

    # LEFT buttons
    left_buttons = [
        ("Home", lambda: None),
        ("EDIBLE", lambda: [root.destroy(), csr.edible_page()]),
        ("WASTE", lambda: [root.destroy(), waste.waste_page()]),
     ("ABOUT US", lambda: [root.destroy(), about.launch_about_us()])
    ]

    for i, (text, cmd) in enumerate(left_buttons):
        tk.Button(nav_bar, text=text, command=cmd, bg="#009CA6", fg="white", bd=0,
                  font=("Arial", 10, "bold"), activebackground="#007B8F", activeforeground="white")\
            .place(x=10 + i * 110, y=5, width=100, height=30)

    # RIGHT buttons
    right_buttons = [
        ("WHO WE ARE", lambda: [root.destroy(), who_we_are.launch_team_page()]),
        ("REGISTER", lambda: [root.destroy(), login.login_window()])
    ]

    for i, (text, cmd) in enumerate(right_buttons):
        tk.Button(nav_bar, text=text, command=cmd, bg="#009CA6", fg="white", bd=0,
                  font=("Arial", 10, "bold"), activebackground="#007B8F", activeforeground="white")\
            .place(x=900 - (2 - i) * 110 - 10, y=5, width=100, height=30)

    # Center campaign message
    canvas.create_text(450, 350, text="Lahore Based Food\nDrive", fill="black",
                       font=("Arial", 28, "bold"), justify="center")

    def donate_action():
        messagebox.showinfo("Donate", "Redirecting to Donation Page...")

    donate_button = tk.Button(root, text="Donate Now", bg="yellow", fg="black", font=("Arial", 12, "bold"),
                              command=donate_action)
    donate_button.place(relx=0.5, y=420, anchor="center")

    root.mainloop()

# ✅ So other pages can go back to home
def main():
    home_page()

if __name__ == "__main__":
    main()
