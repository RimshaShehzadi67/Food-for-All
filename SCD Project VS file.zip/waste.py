import tkinter as tk
from PIL import Image, ImageTk
import subprocess
import sys

def open_page(script):
    root.destroy()
    subprocess.Popen([sys.executable, script])

def open_payment(image_path, title, price):
    subprocess.Popen([sys.executable, "payment.py", image_path, title, price])

def waste_page():
    global root
    root = tk.Tk()
    root.title("Waste Page")
    root.geometry("1200x720")
    root.resizable(False, False)

    # Background
    bg_img = Image.open("assets/1.jpg").resize((1200, 720))
    bg_photo = ImageTk.PhotoImage(bg_img)
    tk.Label(root, image=bg_photo).place(x=0, y=0, relwidth=1, relheight=1)
    root.bg_photo = bg_photo

    # Header
    navbar = tk.Frame(root, bg="#00cfff", height=80)
    navbar.pack(fill="x")
    tk.Label(navbar, text="WASTE", font=("Arial", 28, "bold"), bg="#00cfff").pack(pady=20)

    # Navigation
    nav = tk.Frame(root, bg="#0097A7", height=40)
    nav.pack(fill=tk.X)
    left_nav = tk.Frame(nav, bg="#0097A7")
    left_nav.pack(side=tk.LEFT, padx=10)
    right_nav = tk.Frame(nav, bg="#0097A7")
    right_nav.pack(side=tk.RIGHT, padx=10)

    nav_buttons = {
        "Home": "home.py",
        "EDIBLE": "edible.py",
        "WASTE": "waste.py",
        "ABOUT US": "about_us.py",
        "WHO WE ARE": "who_we_are.py",
        "REGISTER": "register.py"
    }

    for text in ["Home", "EDIBLE", "WASTE", "ABOUT US"]:
        tk.Button(left_nav, text=text, bg="#0097A7", fg="white", font=("Helvetica", 10, "bold"), bd=0,
                  command=lambda s=nav_buttons[text]: open_page(s)).pack(side=tk.LEFT, padx=15)

    for text in ["WHO WE ARE", "REGISTER"]:
        tk.Button(right_nav, text=text, bg="#0097A7", fg="white", font=("Helvetica", 10, "bold"), bd=0,
                  command=lambda s=nav_buttons[text]: open_page(s)).pack(side=tk.LEFT, padx=15)

    # Product Cards
    products = [
        {"image": "assets/9.png", "title": "Ali Farms", "price": "$50.00"},
        {"image": "assets/6.png", "title": "PC Hotel", "price": "$20.00"},
        {"image": "assets/5.png", "title": "Food For All", "price": "$30.00"},
    ]

    def create_card(parent, product):
        card = tk.Frame(parent, bg="white", width=300, height=420)
        card.pack(side="left", padx=30)
        card.pack_propagate(False)

        img = Image.open(product["image"]).resize((210, 140))
        photo = ImageTk.PhotoImage(img)
        card.image = photo
        tk.Label(card, image=photo, bg="white").pack(pady=(20, 10))
        tk.Label(card, text=product["title"], font=("Arial", 14, "bold"), bg="white").pack()
        tk.Label(card, text=product["price"], fg="red", font=("Arial", 13), bg="white").pack(pady=5)
        tk.Label(card, text="★ ★ ★ ★ ☆", fg="orange", font=("Arial", 13), bg="white").pack()
        tk.Button(card, text="LOCATION", bg="orangered", fg="white", font=("Arial", 11, "bold"),
                  padx=20, pady=6,
                  command=lambda: open_payment(product["image"], product["title"], product["price"])
                  ).pack(pady=20)

    card_frame = tk.Frame(root, bg="", padx=40)
    card_frame.pack(pady=40)

    for item in products:
        create_card(card_frame, item)

    root.mainloop()

if __name__ == "__main__":
    waste_page()
