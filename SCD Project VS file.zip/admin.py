import tkinter as tk
from tkinter import PhotoImage
from datetime import date
from PIL import Image, ImageTk

def admin_page():
    admin_window = tk.Toplevel()
    admin_window.title("Admin Dashboard")
    admin_page.state('zoomed')

    admin_window.configure(bg="#E7F7E4")

    # Top Frame with Logo, Title, Date, Button
    top_frame = tk.Frame(admin_window, bg="#ffffff", pady=20)
    top_frame.pack(fill=tk.X)

    logo_img = Image.open("assets/foodforall.jpg")
    logo_img = logo_img.resize((50, 50))
    logo_photo = ImageTk.PhotoImage(logo_img)
    logo_label = tk.Label(top_frame, image=logo_photo, bg="#ffffff")
    logo_label.image = logo_photo
    logo_label.pack(pady=10)

    title = tk.Label(top_frame, text="Welcome Boss!", font=("Helvetica", 24, "bold"), bg="#ffffff")
    title.pack()

    today = date.today().strftime("%d-%m-%Y")
    date_label = tk.Label(top_frame, text=today, font=("Helvetica", 14), bg="#ffffff")
    date_label.pack()

    open_btn = tk.Button(top_frame, text="OPEN", bg="black", fg="white", padx=20, pady=5)
    open_btn.pack(pady=10)

    # Middle Frame with 3 Cards
    mid_frame = tk.Frame(admin_window, bg="#E7F7E4", pady=30)
    mid_frame.pack()

    cards = [
        {
            "image": "assets/89.png",
            "title": "Total Food In Ton",
            "details": ["3 Tons", "Warehouse"]
        },
        {
            "image": "assets/88.png",
            "title": "Sales per Day",
            "details": ["1.5 Ton Approx."]
        },
        {
            "image": "assets/87.png",
            "title": "CSR",
            "details": ["80 kg to orphanage house", "60 kg to our free food spot"]
        }
    ]

    for card in cards:
        card_frame = tk.Frame(mid_frame, bg="white", width=300, height=200, relief=tk.RAISED, bd=2)
        card_frame.pack(side=tk.LEFT, padx=20)

        img = Image.open(card["image"])
        img = img.resize((80, 80))
        photo = ImageTk.PhotoImage(img)
        img_label = tk.Label(card_frame, image=photo, bg="white")
        img_label.image = photo
        img_label.pack(pady=10)

        title = tk.Label(card_frame, text=card["title"], font=("Helvetica", 14, "bold"), fg="green", bg="white")
        title.pack()

        for detail in card["details"]:
            tk.Label(card_frame, text=detail, font=("Helvetica", 12), bg="white").pack()

    # Footer
    footer = tk.Frame(admin_window, bg="#E7F7E4")
    footer.pack(pady=20)

    profit = tk.Label(footer, text="Profit per Day: 50,000 Rs", font=("Helvetica", 14, "bold"), bg="#E7F7E4")
    profit.pack()

    riders_active = tk.Button(footer, text="Riders Active: 38", bg="green", fg="white", font=("Helvetica", 12), padx=20)
    riders_active.pack(pady=10)
