import tkinter as tk
from tkinter import PhotoImage
from PIL import Image, ImageTk
import datetime

def launch_dashboard(rider_name=None):
    if not rider_name:
        rider_name = "Rider"

    root = tk.Tk()
    root.title("Rider Dashboard")
    root.geometry("1366x650")
    root.configure(bg="white")

    rider_img = Image.open("assets/rider.jpeg").resize((200, 200))
    rider_photo = ImageTk.PhotoImage(rider_img)

    money_img = Image.open("assets/earnings.jpeg").resize((100, 100))
    money_photo = ImageTk.PhotoImage(money_img)

    tk.Label(root, text=f"Welcome Rider {rider_name}!", font=("Arial", 28, "bold"), bg="white").place(x=130, y=30)
    tk.Label(root, text=datetime.datetime.now().strftime("%d-%m-%Y"), font=("Arial", 12), bg="white").place(x=1220, y=30)
    tk.Button(root, text="OPEN", bg="black", fg="white", font=("Arial", 10), width=8, height=1).place(x=1220, y=55)
    tk.Label(root, image=rider_photo, bg="white").place(x=90, y=120)

    def create_card(y_pos, departure, destination, amount):
        card = tk.Frame(root, bg="#ecf9ec", width=900, height=80)
        card.place(x=300, y=y_pos)
        tk.Label(card, text="Departure:", font=("Arial", 10, "bold"), bg="#ecf9ec").place(x=20, y=10)
        tk.Label(card, text=departure, font=("Arial", 10), bg="#ecf9ec").place(x=100, y=10)
        tk.Label(card, text="Destination:", font=("Arial", 10, "bold"), bg="#ecf9ec").place(x=20, y=30)
        tk.Label(card, text=destination, font=("Arial", 10), bg="#ecf9ec").place(x=100, y=30)
        tk.Label(card, text=f"Total: Rs {amount:,}", bg="#2d2d2d", fg="white", font=("Arial", 10)).place(x=20, y=55)

    create_card(180, "Fatima Hospital", "Edhi Center", 20000)
    create_card(280, "PC Hotel", "Fatima Group of Fertilizer", 40000)

    tk.Label(root, image=money_photo, bg="white").place(x=1150, y=130)
    tk.Label(root, text="Today's Earning:", font=("Arial", 12), bg="white").place(x=1130, y=250)
    tk.Label(root, text="2000 Rs", font=("Arial", 16), fg="deeppink", bg="white").place(x=1180, y=275)
    tk.Label(root, text="Amount Per Hour:", font=("Arial", 12), bg="white").place(x=1130, y=310)
    tk.Label(root, text="200 Rs", font=("Arial", 16), fg="deeppink", bg="white").place(x=1180, y=335)

    footer = tk.Frame(root, bg="#2d2d2d", height=50, width=1366)
    footer.place(x=0, y=600)
    tk.Label(footer, text="© 2024 Food For All, Inc. All rights reserved.",
             font=("Arial", 10), fg="white", bg="#2d2d2d").place(relx=0.5, rely=0.5, anchor="center")

    root.mainloop()

# ✅ Only run this when directly executing the file
if __name__ == "__main__":
    launch_dashboard("zara")
