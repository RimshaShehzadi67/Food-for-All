import tkinter as tk
from PIL import Image, ImageTk
import os

root = tk.Tk()
root.title("Location")
root.geometry("1200x650")
root.configure(bg='white')

# === Top Blue Navbar ===
navbar = tk.Frame(root, bg="#29a3ef", height=80)
navbar.pack(fill='x')

# Insert logo image instead of text
logo_path = "assets/foodforall.jpg"  # Make sure this file exists
if os.path.exists(logo_path):
    logo_img = Image.open(logo_path).resize((60, 60))
    logo_photo = ImageTk.PhotoImage(logo_img)
    logo_label = tk.Label(navbar, image=logo_photo, bg="#29a3ef")
    logo_label.image = logo_photo
    logo_label.place(x=15, y=10)

# Centered title and tagline
tk.Label(navbar, text="FOOD FOR ALL", fg="white", bg="#29a3ef",
         font=("Arial", 22, "bold")).pack(pady=(10, 0))

tk.Label(navbar, text="Feed All, Treat Well, Donate!", fg="white", bg="#29a3ef",
         font=("Arial", 10)).pack()

# === Main Content Frame ===
main_frame = tk.Frame(root, bg='white')
main_frame.pack(pady=20, padx=20, fill='both', expand=True)

# === Left Card (Food Image & Info) ===
food_card = tk.Frame(main_frame, bg="white", highlightbackground="lightgray",
                     highlightthickness=1, width=550, height=500)
food_card.pack(side='left', padx=20)
food_card.pack_propagate(False)

food_img_path = "assets/98.png"
if os.path.exists(food_img_path):
    image = Image.open(food_img_path).resize((500, 300))
    photo = ImageTk.PhotoImage(image)
    img_label = tk.Label(food_card, image=photo, bg="white")
    img_label.image = photo
    img_label.pack(pady=10)
else:
    tk.Label(food_card, text="[Food Image Missing]", fg="red", bg="white").pack(pady=10)

tk.Label(food_card, text="BIRYANI", font=("Arial", 18, "bold"), bg="white").pack(pady=(10, 0))
tk.Label(food_card, text="FREE", font=("Arial", 14), fg="red", bg="white").pack()

# === Right Card (Location Details) ===
location_card = tk.Frame(main_frame, bg="white", highlightbackground="lightgray",
                         highlightthickness=1, width=550, height=500)
location_card.pack(side='right', padx=20)
location_card.pack_propagate(False)

tk.Label(location_card, text="LOCATION", font=("Arial", 22, "bold"),
         bg="white", fg="black").pack(pady=(40, 30))

# Colored Destination Label
tk.Label(location_card, text="Destination", bg="#ccddde", fg="#060606",
         font=("Arial", 12, "bold"), padx=8, pady=4).pack()
dest_entry = tk.Entry(location_card, width=40, font=("Arial", 11))
dest_entry.insert(0, "Edhi Center")
dest_entry.pack(pady=(0, 20))

# Colored Center Label
tk.Label(location_card, text="Center", bg="#a8b1aa", fg="#0A0A0A",
         font=("Arial", 12, "bold"), padx=8, pady=4).pack()
center_entry = tk.Entry(location_card, width=40, font=("Arial", 11))
center_entry.insert(0, "BHATTA CHOWK")
center_entry.pack(pady=(0, 30))

tk.Button(location_card, text="Available", bg="#ff3b1f", fg="white",
          font=("Arial", 12, "bold"), width=40, height=2, bd=0).pack()

root.mainloop()
