import tkinter as tk
from PIL import Image, ImageTk
import home  # make sure home.py is in the same directory

def launch_about_us():
    root = tk.Tk()
    root.title("Food For All - Aim and Services")
    root.geometry("900x600")

    try:
        bg_image = Image.open("assets/77.png").resize((900, 600), Image.LANCZOS)
        bg_photo = ImageTk.PhotoImage(bg_image)
    except Exception as e:
        print("Error loading image:", e)
        bg_photo = None

    canvas = tk.Canvas(root, width=900, height=600)
    canvas.pack(fill="both", expand=True)

    if bg_photo:
        canvas.create_image(0, 0, image=bg_photo, anchor="nw")

    # Blue Nav Header
    canvas.create_rectangle(0, 0, 900, 70, fill="#00bfff", outline="")
    canvas.create_text(120, 20, text="FOOD FOR ALL", font=("Helvetica", 20, "bold"), fill="white", anchor="nw")
    canvas.create_text(120, 45, text="Feed All, Treat Well, Donate!", font=("Helvetica", 12), fill="white", anchor="nw")

    # Aim Section
    canvas.create_text(20, 120, text="Our Aim", font=("Helvetica", 30, "bold"), fill="white", anchor="nw")
    canvas.create_text(120, 170, text="Feed The Hungry, Train The Young, Waste Less", font=("Helvetica", 16), fill="white", anchor="nw")

    # Services Section
    canvas.create_text(20, 240, text="Our Services", font=("Helvetica", 30, "bold"), fill="white", anchor="nw")
    services_text = (
        "Food For All donates food to the needy, transforms waste\n"
        "into resources for sustainability, and fosters\n"
        "eco-awareness through technology and partnerships."
    )
    canvas.create_text(120, 300, text=services_text, font=("Helvetica", 14), fill="white", anchor="nw")

    def go_home():
        root.destroy()
        home.main()

    home_btn = tk.Button(root, text="HOME", command=go_home, bg="#00bfff", fg="white")
    home_btn.place(x=820, y=20)

    root.bg_photo = bg_photo
    root.mainloop()

if __name__ == "__main__":
    launch_about_us()
