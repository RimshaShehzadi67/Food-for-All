import tkinter as tk
from PIL import Image, ImageTk, ImageDraw
import home, csr, waste, about, login

def launch_team_page():
    def make_circle_image(path, size=(220, 220)):  # Increased image size
        img = Image.open(path).resize(size, Image.Resampling.LANCZOS).convert("RGBA")
        mask = Image.new('L', size, 0)
        draw = ImageDraw.Draw(mask)
        draw.ellipse((0, 0) + size, fill=255)
        img.putalpha(mask)
        background = Image.new("RGBA", size, (255, 255, 255, 0))
        background.paste(img, (0, 0), mask=img)
        return ImageTk.PhotoImage(background)

    root = tk.Tk()
    root.title("Food For All - Team Section")
    root.geometry("1000x700")  # Slightly increased window size
    root.configure(bg="#E5E9EB")

    # Header Banner
    banner = tk.Frame(root, bg="#00bfff", height=80)
    banner.pack(fill=tk.X)

    tk.Label(banner, text="FOOD FOR ALL", bg="#00bfff", fg="white", font=("Helvetica", 20, "bold")).pack(pady=(10, 0))
    tk.Label(banner, text="Feed All, Treat Well, Donate!", bg="#00bfff", fg="white", font=("Helvetica", 12)).pack()

    # Top Navigation Bar
    nav_bar = tk.Frame(root, bg="#009CA6", height=40)
    nav_bar.pack(fill=tk.X)

    nav_buttons = [
        ("Home", lambda: [root.destroy(), home.main()]),
        ("EDIBLE", lambda: [root.destroy(), csr.edible_page()]),
        ("WASTE", lambda: [root.destroy(), waste.waste_page()]),
        ("ABOUT US", lambda: [root.destroy(), about.about_page()]),
        ("REGISTER", lambda: [root.destroy(), login.login_window()])
    ]

    for i, (text, command) in enumerate(nav_buttons):
        tk.Button(nav_bar, text=text, command=command, bg="#009CA6", fg="white", bd=0,
                  font=("Arial", 10, "bold"), activebackground="#007B8F", activeforeground="white")\
            .place(x=10 + i * 110, y=5, width=100, height=30)

    # Section Title
    tk.Label(root, text="Meet Our Team", bg="#f1f1f1", fg="#333", font=("Helvetica", 20, "bold")).pack(pady=25)

    # Team Cards
    team_frame = tk.Frame(root, bg="#eff1f2")
    team_frame.pack()

    # Load and shape images
    zara_img = make_circle_image("assets/person1.jpeg")
    anam_img = make_circle_image("assets/person3.jpg")

    # Prevent garbage collection
    root.team_images = [zara_img, anam_img]

    def create_card(parent, image, name, role):
        card = tk.Frame(parent, bg="white", bd=2, relief="groove", padx=30, pady=20, width=300, height=380)
        card.pack_propagate(False)
        card.pack(side=tk.LEFT, padx=40)
        tk.Label(card, image=image, bg="white").pack(pady=10)
        tk.Label(card, text=name, font=("Helvetica", 14, "bold"), bg="white", fg="#333").pack()
        tk.Label(card, text=role, font=("Helvetica", 11), bg="white", fg="#777").pack()

    # Create cards
    create_card(team_frame, zara_img, "Zara Naeem", "CEO & Founder")
    create_card(team_frame, anam_img, "Anam Khan", "Customer Support Lead")

    root.mainloop()

if __name__ == "__main__":
    launch_team_page()
