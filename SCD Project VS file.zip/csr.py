import tkinter as tk
from PIL import Image, ImageTk
import os
import subprocess
import sys

def open_location_window():
    subprocess.Popen([sys.executable, "location.py"])

def open_page(script):
    root.destroy()
    subprocess.Popen([sys.executable, script])

def edible_page():
    global root
    root = tk.Tk()
    root.title("EDIBLE")
    root.geometry("1200x750")
    root.resizable(False, False)

    # Background
    bg_path = "assets/1.jpg"
    if os.path.exists(bg_path):
        bg_image = Image.open(bg_path).resize((1200, 750))
        bg_photo = ImageTk.PhotoImage(bg_image)
        tk.Label(root, image=bg_photo).place(x=0, y=0, relwidth=1, relheight=1)
        root.bg_photo = bg_photo  # Prevent garbage collection

    # Header
    navbar = tk.Frame(root, bg="#00cfff", height=80)
    navbar.pack(fill="x")
    tk.Label(navbar, text="EDIBLE", font=("Arial", 28, "bold"), bg="#00cfff").pack(pady=20)

    # Navigation bar
    nav = tk.Frame(root, bg="#0097A7", height=40)
    nav.pack(fill=tk.X)
    left_nav = tk.Frame(nav, bg="#0097A7")
    left_nav.pack(side=tk.LEFT, padx=10)
    right_nav = tk.Frame(nav, bg="#0097A7")
    right_nav.pack(side=tk.RIGHT, padx=10)

    nav_buttons = {
        "Home": "home.py",
        "EDIBLE": "edible.py",
        "WASTE": "waste.py",
        "ABOUT US": "about_us.py",
        "WHO WE ARE": "who_we_are.py",
        "REGISTER": "register.py"
    }

    for text in ["Home", "EDIBLE", "WASTE", "ABOUT US"]:
        tk.Button(left_nav, text=text, bg="#0097A7", fg="white", font=("Helvetica", 10, "bold"), bd=0,
                  command=lambda s=nav_buttons[text]: open_page(s)).pack(side=tk.LEFT, padx=15)

    for text in ["WHO WE ARE", "REGISTER"]:
        tk.Button(right_nav, text=text, bg="#0097A7", fg="white", font=("Helvetica", 10, "bold"), bd=0,
                  command=lambda s=nav_buttons[text]: open_page(s)).pack(side=tk.LEFT, padx=15)

    # Main Frame
    main_frame = tk.Frame(root, bg=None)
    main_frame.pack(pady=40)

    foods = [
        {"name": "BIRYANI", "image": "assets/98.png", "rating": 4},
        {"name": "SAMOSA", "image": "assets/9.jpg", "rating": 3},
        {"name": "VEGETABLE RICE", "image": "assets/96.png", "rating": 5},
    ]

    def create_card(parent, food):
        card = tk.Frame(parent, width=300, height=420, bg='white')
        card.pack(side=tk.LEFT, padx=25)
        card.pack_propagate(False)

        content = tk.Frame(card, bg='white')
        content.place(relx=0.5, rely=0.5, anchor='center')

        if os.path.exists(food["image"]):
            img = Image.open(food["image"]).resize((270, 200))
            photo = ImageTk.PhotoImage(img)
            img_label = tk.Label(content, image=photo, bg='white')
            img_label.image = photo
            img_label.pack(pady=(0, 10))
        else:
            tk.Label(content, text="[Image Missing]", fg="red", bg='white').pack(pady=(0, 10))

        tk.Label(content, text=food["name"], font=("Arial", 16, "bold"), bg='white').pack()
        tk.Label(content, text="FREE", fg="red", font=("Arial", 12), bg='white').pack(pady=3)
        stars = "★" * food["rating"] + "☆" * (5 - food["rating"])
        tk.Label(content, text=stars, font=("Arial", 14), fg="#fbc02d", bg='white').pack(pady=5)

        tk.Button(content, text="LOCATION", font=("Arial", 11, "bold"),
                  bg="#ff3d00", fg="white", padx=20, pady=6, bd=0,
                  command=open_location_window).pack(pady=12)

    for food in foods:
        create_card(main_frame, food)

    root.mainloop()

if __name__ == "__main__":
    edible_page()
